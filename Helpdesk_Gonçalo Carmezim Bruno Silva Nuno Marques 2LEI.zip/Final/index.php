<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina Inicial</title>
    <link rel="stylesheet" href="css/style_index.css">
    <style>
        
    </style>
</head>
<body>

<div class="container">
    <h1>TechHelp</h1>
    <p>Your help for Tech!</p>
    <p>If you already have an account, <a href="login.php">login here</a>.</p>
    <p>If not contact your chief Dept.</p>
</div>

</body>
</html>
